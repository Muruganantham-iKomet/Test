﻿namespace Smidge.Hashing
{
    public interface IHasher
    {
        string Hash(string input);
    }
}
﻿namespace Smidge
{
    public class SmidgeConstants
    {
        public const string SchemeDelimiter = "://";
    }
}

﻿using System;

namespace Smidge.Models
{
    public enum WebFileType
    {
        Js, Css
    }
}
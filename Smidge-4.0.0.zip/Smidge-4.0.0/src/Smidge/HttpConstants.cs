﻿namespace Smidge
{
    internal class HttpConstants
    {
        internal const string HttpDateFormat = "r";
    }
}